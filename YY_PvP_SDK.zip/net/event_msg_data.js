var event_msg_data = cc.Class({
    properties: {
        cmd: 0,
        data: 0,
    },
});