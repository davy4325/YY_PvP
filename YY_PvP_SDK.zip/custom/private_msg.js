var private_msg = {
    /*-------------- pvp sdk info ----------------*/
    company_guid: "fd9d4907-3c34-4b66-a908-3b79816546a8",
    game_type: 1,

    /*---------------local msg---------------*/
}
module.exports = private_msg;