var private_msg = {
    /*-------------- pvp sdk info ----------------*/
    company_guid: "fd9d4907-3c34-4b66-a908-3b79816546a8",
    game_type: 1,

    /*---------------local msg---------------*/
    local_msg_init_round_data: 10001,
    local_msg_play_left: 10002,
    local_msg_play_right: 10003,
    local_msg_play_stop: 10004,
    local_msg_game_over: 10005,
}
module.exports = private_msg;