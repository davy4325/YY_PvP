const AMFObject = require('../net/AMF/AMFObject');
const AMFArray = require('../net/AMF/AMFArray');

var private_code = cc.Class({
    statics: {
      
    }
});